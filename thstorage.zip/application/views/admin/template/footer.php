<footer class="sticky-footer" style="margin-top: 15px;">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span style="color: #fff">Copyright © SynoDev - Wahyu Ramadhani</span>
		</div>
	</div>
</footer>